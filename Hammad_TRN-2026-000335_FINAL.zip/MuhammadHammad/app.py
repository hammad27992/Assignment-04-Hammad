from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "student_model.joblib"
DATA_PATH = BASE_DIR / "student_learning.csv"

st.set_page_config(page_title="Student Performance Prediction", page_icon="📘")
st.title("Student Performance Prediction App")
st.write("Enter student details to estimate the pass/fail outcome using the trained model.")

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

@st.cache_data
def load_study_methods():
    data = pd.read_csv(DATA_PATH)
    methods = sorted(data["study_method"].dropna().astype(str).unique().tolist())
    return methods or ["self", "group", "video"]

try:
    model = load_model()
    methods = load_study_methods()
except Exception as exc:
    st.error(f"Could not load the model or dataset: {exc}")
    st.stop()

with st.form("prediction_form"):
    hours = st.number_input("Hours Studied", min_value=0.0, max_value=24.0, value=5.0, step=0.5)
    attendance = st.number_input("Attendance (%)", min_value=0, max_value=100, value=75)
    tests = st.number_input("Practice Tests Taken", min_value=0, max_value=50, value=2)
    sleep = st.number_input("Sleep Hours", min_value=0.0, max_value=24.0, value=7.0, step=0.5)
    method = st.selectbox("Study Method", methods)
    submitted = st.form_submit_button("Predict")

if submitted:
    input_data = pd.DataFrame({
        "hours_studied": [hours],
        "attendance": [attendance],
        "practice_tests": [tests],
        "sleep_hours": [sleep],
        "study_method": [method],
    })
    prediction = int(model.predict(input_data)[0])
    if prediction == 1:
        st.success("Prediction: The student is likely to PASS.")
    else:
        st.warning("Prediction: The student is likely to FAIL.")
    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(input_data)[0]
        st.write(f"Estimated pass probability: {probabilities[list(model.classes_).index(1)]:.1%}")

st.caption("For educational demonstration only. Do not use this prediction as the sole basis for real educational decisions.")
