# Model Card — Student Pass Prediction

## Model details
- **Model:** Random Forest Classifier inside a Scikit-learn Pipeline
- **Task:** Binary classification (`passed`: 0 = fail, 1 = pass)
- **Student:** Muhammad Hammad
- **Student ID:** TRN-2026-000335
- **Dataset:** Supplied `student_learning.csv` (280 rows, 7 columns)

## Intended use
Educational assignment and demonstration of a machine-learning workflow. It is not intended for high-stakes decisions about real students.

## Data and features
Input features: `hours_studied`, `attendance`, `practice_tests`, `sleep_hours`, and `study_method`. The `passed` column is the target. `final_score` is excluded from model inputs to reduce target leakage.

## Data quality
- Missing values: 0
- Duplicate rows: 0
- Class counts: fail (0) = 157; pass (1) = 123

## Evaluation
A stratified 80/20 train/test split was used (`random_state=42`).

| Model | Test accuracy |
|---|---:|
| Dummy Classifier | 0.5536 |
| Logistic Regression | 0.7500 |
| Random Forest | 0.7679 |

Detailed classification reports and confusion matrices are generated in `ml_assignment.ipynb`.

## Limitations and risks
- The dataset is small and may be synthetic or otherwise not representative of a real student population.
- Predictions may reflect biases or patterns in the supplied data.
- The model does not establish causation and should not be used to label or penalize students.
- Performance may change on new data; external validation is required before any real-world use.

## Ethical considerations
Use predictions only as a learning aid. Do not make consequential educational decisions from this model alone. Protect student data and obtain appropriate permission before using personal records.

## Reproducibility
Run all cells in `ml_assignment.ipynb` from the project folder. The notebook saves `student_model.joblib`; `app.py` loads that pipeline for interactive predictions.
