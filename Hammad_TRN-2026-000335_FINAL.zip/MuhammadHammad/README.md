# Assignment 04 — Student Learning Prediction

**Student:** Muhammad Hammad  
**Student ID:** TRN-2026-000335

## Project overview
This project uses the supplied `student_learning.csv` dataset to classify whether a student passes (`passed`: 0 = fail, 1 = pass). It demonstrates data inspection, preprocessing, a Dummy Classifier baseline, Logistic Regression, Random Forest, evaluation, model persistence, and a Streamlit prediction interface.

## Dataset and features
The dataset contains 280 rows and 7 columns. Model input features are `hours_studied`, `attendance`, `practice_tests`, `sleep_hours`, and `study_method`. The target is `passed`. `final_score` is excluded from the model features to avoid target leakage.

## Files
- `ml_assignment.ipynb` — complete notebook with data inspection, train/test split, preprocessing, model training, classification reports, confusion matrices, saving and reloading the model.
- `student_learning.csv` — supplied dataset.
- `student_model.joblib` — trained Random Forest pipeline, including preprocessing.
- `app.py` — Streamlit app for pass/fail prediction.
- `MODEL_CARD.md` — intended use, evaluation summary, limitations, and ethical considerations.
- `requirements.txt` — Python package dependencies.

## Run the project
Use Python 3.10 or later. Open a terminal in this folder and run:

```bash
pip install -r requirements.txt
```

Run all cells in `ml_assignment.ipynb` from top to bottom to reproduce the training and evaluation and regenerate `student_model.joblib`. Then start the app:

```bash
streamlit run app.py
```

## Evaluation summary
The notebook reports test accuracy, precision, recall, F1-score, and confusion matrices for the Dummy Classifier, Logistic Regression, and Random Forest using the same stratified test set. See the notebook and `MODEL_CARD.md` for the measured results.

## Repository
https://github.com/hammad27992/Assignment-04-Hammad

## Important note
This is an educational project. The dataset is small and may not represent real student populations. Predictions should not be used as the sole basis for consequential educational decisions.
